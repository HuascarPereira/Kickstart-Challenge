# Kickstarting with Excel

## Overview of Project

### With this dataset, we're helping Louise prepare for her next round of campaings based on which campaigns were found more successful than others and when to begin launching those campaigns. This analysis will be based on two main factors, 1) outcomes based on launch dates and 2) outcomes based on goals

## Analysis and Challenges

### Analysis of Outcomes Based on Launch Date - Based on the campaing launch dates, we can make a conclusion/analysis that the spring-summer months (Feb-May) are more successful than the second half of the year for theater campaings. 

### Analysis of Outcomes Based on Goals - Based on the goals, it seems that the higher the goal gets, the less likely it is for Loise to achieve a successful campaign.

### Challenges and Difficulties Encountered - Need further assistance when it comes to representing correct axis and choosing columns to represent on graph. 

## Results

- What are two conclusions you can draw about the Outcomes based on Launch Date? 1) Summer months bring in higher success for the campaign and 2) lower to mid-range level goals for campaigns are more attainable. 

- What can you conclude about the Outcomes based on Goals? - Higher goals might be too ambitious for Loise to execute. 

- What are some limitations of this dataset? - only 1 year worth of data...

- What are some other possible tables and/or graphs that we could create? - Bar graphs, cluster, scatter graphs. 
